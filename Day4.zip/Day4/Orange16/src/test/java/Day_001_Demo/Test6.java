package Day_001_Demo;

import org.testng.annotations.Test;

public class Test6 {
  @Test
  public void f() {
  }
}
