package seleniumgluecode1;

import org.testng.annotations.Test;

public class glueskills {
  @Test
  public void f() {
  }
}
